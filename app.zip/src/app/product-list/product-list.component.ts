import { NONE_TYPE } from '@angular/compiler';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppDataService } from '../app-data.service';

import { IndependentCommunicationService } from '../services/independent-communication.service';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit, OnDestroy {
  toggleGuideHelpFlyout: any;

  constructor(public appDataService: AppDataService, private router: Router,
              private independentCommunicationService: IndependentCommunicationService) {

  }

  ngOnInit(): void {
    this.appDataService.productCategory = false;
    this.independentCommunicationService.sendIndependentComponentResponse(false);
  }


  productItemToggleEvent($event) {
    console.log('CHILD TO PARENT-->', $event);
    this.toggleGuideHelpFlyout = $event;
  }

  ngOnDestroy() {
    this.appDataService.productCategory = true;
  }

  back() {
    this.router.navigate(['productCategory']);
  }

}
