import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list-items',
  templateUrl: './product-list-items.component.html',
  styleUrls: ['./product-list-items.component.scss']
})
export class ProductListItemsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
