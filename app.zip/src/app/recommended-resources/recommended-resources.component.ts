import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recommended-resources',
  templateUrl: './recommended-resources.component.html',
  styleUrls: ['./recommended-resources.component.scss']
})
export class RecommendedResourcesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
