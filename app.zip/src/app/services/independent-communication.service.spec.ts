import { TestBed } from '@angular/core/testing';

import { IndependentCommunicationService } from './independent-communication.service';

describe('IndependentCommunicationService', () => {
  let service: IndependentCommunicationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IndependentCommunicationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
