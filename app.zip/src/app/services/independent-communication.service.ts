import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IndependentCommunicationService {
  private subject = new Subject<any>();
  constructor() { }
  sendIndependentComponentResponse(response: any) {
    this.subject.next({ independentComponentData: response });
  }

  clearMessages() {
    this.subject.next();
  }

  onResponse(): Observable<any> {
    return this.subject.asObservable();
  }
}
