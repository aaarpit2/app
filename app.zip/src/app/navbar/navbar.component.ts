import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppDataService } from '../app-data.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { IndependentCommunicationService } from '../services/independent-communication.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  toggleNavBtn = true;
  constructor(public appDataService: AppDataService, private route: ActivatedRoute, private router: Router,
              private independentCommunicationService: IndependentCommunicationService) { }

  ngOnInit(): void {
    this.subscription = this.independentCommunicationService.onResponse().subscribe(responseData => {
      this.toggleNavBtn = responseData.independentComponentData;
    });
  }

  showProducts() {
    //  this.appDataService.showProducts = true;
    window.scroll({ top: 1455, left: 0, behavior: 'smooth' }); // scroll till product
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
}

}
