import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-navbar-link',
  templateUrl: './product-navbar-link.component.html',
  styleUrls: ['./product-navbar-link.component.scss']
})
export class ProductNavbarLinkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
