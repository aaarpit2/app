import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductNavbarLinkComponent } from './product-navbar-link.component';

describe('ProductNavbarLinkComponent', () => {
  let component: ProductNavbarLinkComponent;
  let fixture: ComponentFixture<ProductNavbarLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductNavbarLinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductNavbarLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
