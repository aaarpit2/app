import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewServicesComponent } from './view-services/view-services.component';
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule
    ],
    declarations: [
        ViewServicesComponent
    ],
    exports: [
        CommonModule,
        ViewServicesComponent
    ],
    entryComponents: [
    ],
    providers: [
    ]
})
export class SharedModule { }
