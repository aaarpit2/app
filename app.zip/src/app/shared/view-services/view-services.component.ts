import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-services',
  templateUrl: './view-services.component.html',
  styleUrls: ['./view-services.component.scss']
})
export class ViewServicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
