import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppDataService {
  productCategory = true;
  showProducts = false;

  constructor() { }
}
