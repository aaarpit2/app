import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppDataService } from '../app-data.service';
import { IndependentCommunicationService } from '../services/independent-communication.service';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  constructor(private router: Router, public appDataService: AppDataService,
              private independentCommunicationService: IndependentCommunicationService) { }

  ngOnInit(): void {
  }

  explore() {
    this.router.navigate(['productCategory']);
    this.independentCommunicationService.sendIndependentComponentResponse(false);
    window.scroll({ top: 0, left: 0, behavior: 'smooth' }); // scroll till product
  }

  back() {
    this.appDataService.showProducts = false;
  }

}
