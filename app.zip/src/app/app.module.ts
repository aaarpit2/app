import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RecommendedResourcesComponent } from './recommended-resources/recommended-resources.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductCategoriesComponent } from './product-categories/product-categories.component';
import { AppDataService } from './app-data.service';
import { IndependentCommunicationService } from './services/independent-communication.service';
import { FeaturesBenefitsComponent } from './features-benefits/features-benefits.component';
import { SolutionsComponent } from './solutions/solutions.component';
import { ProductsComponent } from './products/products.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { SharedModule } from './shared/shared.module';
import { ProductCategoriesItemsComponent } from './product-categories/product-categories-items/product-categories-items.component';
import { ProductListItemsComponent } from './product-list/product-list-items/product-list-items.component';
import { ProductFiltersComponent } from './product-list/product-filters/product-filters.component';
import { ProductNavbarLinkComponent } from './product-navbar-link/product-navbar-link.component';
import { WidgetsComponent } from './widgets/widgets.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    RecommendedResourcesComponent,
    ProductListComponent,
    ProductCategoriesComponent,
    FeaturesBenefitsComponent,
    SolutionsComponent,
    ProductsComponent,
    ProductCategoriesItemsComponent,
    ProductListItemsComponent,
    ProductFiltersComponent,
    ProductNavbarLinkComponent,
    WidgetsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    MatAutocompleteModule,
    MatExpansionModule,
    MatInputModule,
    MatFormFieldModule,
  ],
  exports: [
    MatInputModule,
    MatFormFieldModule
  ],
  providers: [AppDataService, IndependentCommunicationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
