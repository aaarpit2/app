import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-features-benefits',
  templateUrl: './features-benefits.component.html',
  styleUrls: ['./features-benefits.component.scss']
})
export class FeaturesBenefitsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
