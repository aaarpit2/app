import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IndependentCommunicationService } from '../services/independent-communication.service';
@Component({
  selector: 'app-product-categories',
  templateUrl: './product-categories.component.html',
  styleUrls: ['./product-categories.component.scss']
})
export class ProductCategoriesComponent implements OnInit {

  constructor(private router: Router, private independentCommunicationService: IndependentCommunicationService) { }

  ngOnInit(): void {
    this.independentCommunicationService.sendIndependentComponentResponse(false);
  }

  back() {
    this.router.navigate(['products']);
    this.independentCommunicationService.sendIndependentComponentResponse(true);
  }
}
