import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-product-categories-items',
  templateUrl: './product-categories-items.component.html',
  styleUrls: ['./product-categories-items.component.scss']
})
export class ProductCategoriesItemsComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  explore() {
    this.router.navigate(['productList']);
  }

}
