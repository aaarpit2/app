import { Component, Input } from '@angular/core';
import { AEMService } from './aem.service';

@Component({
  selector: 'aem',
  templateUrl: './aem.component.html'
})
export class AEMComponent {
  @Input() userId: string;
  @Input() url: string;
  @Input() htmlresponse: string;

  constructor(private aemService: AEMService) {
	}

  ngOnInit(): void {
    this.aemService.getAEMFragmentBody().subscribe(res => {
      this.htmlresponse = res;
    });
  }
}
