import { Component, Input } from '@angular/core';

@Component({
  selector: 'healthcheck',
  templateUrl: './healthcheck.component.html'
})
export class HealthCheckComponent {
 
  constructor() {
	}
  ngOnInit(): void { 
  }
}
