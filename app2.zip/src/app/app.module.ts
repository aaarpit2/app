import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MainUIComponent } from 'src/main/mainui.component';
import { AEMComponent } from 'src/aem/aem.component';
import { AccessComponent } from 'src/access/access.component';
import { CMSComponent } from 'src/cms/cms.component';
import { UploadFileComponent } from 'src/uploadfile/uploadfile.component';
import { SafeHtmlPipe } from 'src/utils/safehtml.pipe';
import { WsmenubarModule } from 'wsmenubar';
import { MenubarComponent } from 'src/menubar/menubar.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxFileDropModule } from 'ngx-file-drop';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { UserEffects } from '../store/effects';

import { reducer } from '../store/reducer';
import { CatalogComponent } from 'src/catalog/catalog.component';

@NgModule({
  imports: [
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    WsmenubarModule,
    NgbModule,
    NgxFileDropModule,
    FontAwesomeModule,
    BrowserModule,
    StoreModule.forRoot([reducer]),
    EffectsModule.forRoot([UserEffects]),
  ],
  declarations: [
    AppComponent,
    MainUIComponent,
    MenubarComponent,
    AEMComponent,
    SafeHtmlPipe,
    UploadFileComponent,
    CMSComponent,
    AccessComponent,
    CatalogComponent,
  ],
  providers: [],
  exports: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
