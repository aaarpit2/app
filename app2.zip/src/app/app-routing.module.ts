import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { from } from 'rxjs';
import { AccessComponent } from 'src/access/access.component';
import { AEMComponent } from 'src/aem/aem.component';
import { CMSComponent } from 'src/cms/cms.component';
import { HealthCheckComponent } from 'src/healthcheck/healthcheck.component';
import { MainUIComponent } from 'src/main/mainui.component';
import { UploadFileComponent } from 'src/uploadfile/uploadfile.component';
import { CatalogComponent } from 'src/catalog/catalog.component';

const routes: Routes = [
  { path: 'healthcheck', component: HealthCheckComponent },
  {
    path: '',
    component: MainUIComponent,
    children: [
      { path: 'adminui', component: UploadFileComponent },
      { path: 'dna', component: AEMComponent },
      { path: 'catalog', component: CatalogComponent },
      { path: 'offers/:id', component: CMSComponent },
      { path: '**', component: AccessComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
