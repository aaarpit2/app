import { Component, Input } from '@angular/core';
import { CMSService } from './cms.service';

@Component({
  selector: 'cms',
  templateUrl: './cms.component.html'
})
export class CMSComponent {
  @Input() userId: string;
  @Input() url: string;
  @Input() htmlresponse: string;

  constructor(private aemService: CMSService) {
	}

  ngOnInit(): void {
  /*  this.aemService.getAEMFragmentBody().subscribe(res => {
      this.htmlresponse = res;
    }); */
  }
}
