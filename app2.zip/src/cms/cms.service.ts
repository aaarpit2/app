import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CMSService {

  constructor(private http: HttpClient) {}

  getServiceParams() {
    let httpOptions =  {
      responseType: 'html',
      withCredentials: false,
      headers: new HttpHeaders({
        'Content-Type': 'text/plain'
      }) 
    };
    
    return {body: null, httpOptions: httpOptions};
  }

  getAEMFragmentBody():  Observable<any>  {
	  let params: any = this.getServiceParams();
	  return this.http.get<any>("https://fdk-stage.cisco.com/c/experience-fragments/infographic/security/en_us/upgrademergeinfo/UpgradeMergeBuild/anchor-marquee-v2--0004.html", params.httpOptions);
  }

}
