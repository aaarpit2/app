import { Component, Input, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { UserProfileService } from 'src/userprofile/userprofile.service';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import * as fromRoot from '../store/reducer';

@Component({
  selector: 'mainui-root',
  templateUrl: './mainui.component.html',
  styleUrls: ['./mainui.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MainUIComponent {
  @Input() userId: string;
  userData: any;
  allowAccess: Boolean;

  constructor(
    private userProfileService: UserProfileService,
    private router: Router,
    private store: Store<fromRoot.State>
  ) {
    this.store
      .select((state) => state)
      .subscribe((data) => {
        console.log(data[0].results);
        this.userData = data[0].results;
        sessionStorage.setItem('userData', JSON.stringify(this.userData));
        this.setAllowAccess();
      });
  }

  setAllowAccess(): void {
    const url = this.router.url;
    const path = url.replace('/', '');
    if (
      (this.userData &&
        (this.userData.accessLevel === '2' ||
          this.userData.accessLevel === '3' ||
          this.userData.accessLevel === '4')) ||
      path === 'adminui'
    ) {
      this.allowAccess = true;
    }
  }

  ngOnInit(): void {
    /* if (sessionStorage.getItem('userData')) {
      this.userData = JSON.parse(sessionStorage.getItem('userData'));
      this.setAllowAccess();
    } else {
      // call user profile service to fetch the user data
      this.userProfileService.fetchUserDetail().subscribe(
        (res) => {
          this.userData = res;
          sessionStorage.setItem('userData', JSON.stringify(res));
          this.setAllowAccess();
        },
        (error) => {
          console.error('Error in parsing user profile response error:', error);
        }
      );
    } */
  }
}
