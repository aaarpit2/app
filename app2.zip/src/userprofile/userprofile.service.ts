import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {



  constructor(private http: HttpClient) {}

  getUserDetailRequest() {
    let httpOptions =  {
      responseType: 'json',
      withCredentials: false,
      headers: new HttpHeaders({
        'Content-Type' : 'text/plain'
      }) 
    };  
    return {httpOptions: httpOptions};
  }

  fetchUserDetail():  Observable<any>  {
	  let params: any = this.getUserDetailRequest();
	  return this.http.get<any>("/api/userDetails", params.httpOptions);
  }

  parseUserDetailResponse(res: Response){
	  let body = res.json();
    return body;
  }

}
