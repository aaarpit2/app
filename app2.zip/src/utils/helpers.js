export const isObject = obj => Object.keys(obj).length > 0 && obj.constructor === Object;
export const isNull = val => val === null;
