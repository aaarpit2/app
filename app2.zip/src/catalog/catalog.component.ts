import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.scss'],
})
export class CatalogComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    let globalValue = {
      template: 'category_temp_1',
      recommendation_tile_heading: 'Recommended Resources',
      tile_block_heading: 'Product categories to choose from',
      children: [
        {
          recommendations_tile_details:
            'recommendations_onlinetool, recommendations_assessment, recommendations_healthcare',
          recommendation_tile_heading: 'Recommended Resources',
          tile_block_heading: 'Please select one of the available products',
          banner_id: 'banner_dna_product',
          category_tile_id: 'tile_indoor_ap',
          id: 'indoor_access_points',
          type: 'CATEGORY',
          additional_content: 'recommendation_service',
        },
        {
          recommendations_tile_details:
            'recommendations_onlinetool, recommendations_assessment, recommendations_healthcare',
          recommendation_tile_heading: 'Recommended Resources',
          tile_block_heading: 'Please select one of the available products',
          banner_id: 'banner_dna_product',
          category_tile_id: 'tile_wireless_controllers',
          id: 'wireless_controller',
          type: 'CATEGORY',
          additional_content: 'recommendation_service',
        },
        {
          recommendations_tile_details:
            'recommendations_onlinetool, recommendations_assessment, recommendations_healthcare',
          recommendation_tile_heading: 'Recommended Resources',
          tile_block_heading: 'Please select one of the available products',
          banner_id: 'banner_dna_product',
          category_tile_id: 'tile_controllerless_ap',
          id: 'controllerless_access_points',
          type: 'CATEGORY',
          additional_content: 'recommendation_service',
        },
      ],
      banner_id: [
        {
          imageurl:
            'https://www.cisco.com/c/dam/global/en_au/solutions/small-business/assets/images/compute/ucs-c3260-Intel.jpg',
          description:
            "Cisco product protofolio is centrally managed from an intuitive interface. It's simply better IT.",
          id: 'banner_smart_product',
          type: 'BANNER',
          title: 'Smart IT products',
        },
      ],
      id: 'wireless',
      type: 'TECHNOLOGY',
      additional_content: [
        {
          target_link2_url:
            'https://www.cisco.com/c/dam/global/en_au/solutions.html',
          link1_title: 'View our services',
          target_link1_url:
            'https://www.cisco.com/c/dam/global/en_au/solutions.html',
          imageurl:
            'https://www.cisco.com/c/dam/global/en_au/solutions/small-business/assets/images/compute/ucs-c3260-Intel.jpg',
          link2_title: 'View our services',
          description:
            'Confidently move to a secure, automated, intent-based network with expert guidance, proven experience, best practices, and innovative ideas.',
          id: 'recommendation_service',
          type: 'RECOMMENDATION',
          title:
            'Accelerate your success with services from Cisco Customer Experience.',
        },
      ],
      recommendations_tile_details: [
        {
          target_link2_url:
            'https://www.cisco.com/c/dam/global/en_au/solutions.html',
          link1_title: 'View our services',
          target_link1_url:
            'https://www.cisco.com/c/dam/global/en_au/solutions.html',
          imageurl:
            'https://www.cisco.com/c/dam/global/en_au/solutions/small-business/assets/images/compute/ucs-c3260-Intel.jpg',
          link2_title: 'View our services',
          description:
            'Confidently move to a secure, automated, intent-based network with expert guidance, proven experience, best practices, and innovative ideas.',
          id: 'recommendation_service',
          type: 'RECOMMENDATION',
          title:
            'Accelerate your success with services from Cisco Customer Experience.',
        },
      ],
    };
  }
}
