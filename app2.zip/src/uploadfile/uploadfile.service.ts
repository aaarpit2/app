import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class UploadFileService {
  constructor(private http: HttpClient) {}

  getServiceParams() {
    let httpOptions = {
      responseType: 'blob',
      withCredentials: false,
      headers: new HttpHeaders({
        'Content-Type': 'multipart/form-data',
      }),
    };

    return { httpOptions };
  }

  callUploadFileService(formData): Observable<any> {
    let params: any = this.getServiceParams();
    return this.http
      .post<any>(
        // "https://fdk-stage.cisco.com/c/experience-fragments/infographic/security/en_us/upgrademergeinfo/UpgradeMergeBuild/anchor-marquee-v2--0004.html",
        'http://localhost:8080/uploadFile',
        formData,
        params.httpOptions
      )
      .pipe(
        map((res: any) => console.log('res', res.json())),
        catchError((err: any) => {
          return Observable.throw(err);
        })
      );
  }
}
