/* Module Dependencies */
import {
  Component,
  Input,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import {
  NgxFileDropEntry,
  FileSystemFileEntry,
  FileSystemDirectoryEntry,
} from 'ngx-file-drop';
import {
  faCheck,
  faExclamationTriangle,
} from '@fortawesome/free-solid-svg-icons';

import { UploadFileService } from './uploadfile.service';
import { isObject, isNull } from '../utils/helpers';

/* Declare Component */
@Component({
  selector: 'uploadfile',
  templateUrl: './uploadfile.component.html',
  styleUrls: ['./uploadfile.component.scss'],
})

/* Export Compnent */
export class UploadFileComponent {
  title = 'appBootstrap';
  acceptedFormat =
    '.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel';
  validFileTypes = ['xls', 'xlsx'];
  successMessage = 'Successfully uploaded the file!';
  closeAlert = false;
  faCheck = faCheck;
  faExclamationTriangle = faExclamationTriangle;

  closeResult: string;

  @ViewChild('modal_1') modal_1: TemplateRef<any>;
  @ViewChild('vc', { read: ViewContainerRef }) vc: ViewContainerRef;
  backdrop: any;

  form: FormGroup;
  error: string;
  userId: number = 1;
  userData: any;
  isAdminAccess: boolean;
  ipcAccess = true;
  isUploadSuccess: boolean;
  uploadResponse = { status: '', message: '', filePath: '' };

  constructor(
    private formBuilder: FormBuilder,
    private modalService: NgbModal,
    private uploadService: UploadFileService
  ) {}

  public files: NgxFileDropEntry[] = [];

  public dropped(files: NgxFileDropEntry[]) {
    const fileName = files[0].relativePath;
    const fileExt = fileName.split('.').pop();
    console.log('filename', fileName);
    if (this.validFileTypes.indexOf(fileExt) > -1) {
      this.files = files;
      this.form.controls['uploadErrMsg'].setErrors(null);
    } else {
      this.form.controls['uploadErrMsg'].setErrors({ uploadErrMsg: true });
    }
  }

  public fileOver(event) {
    console.log(event);
  }

  public fileLeave(event) {
    console.log(event);
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      uploadErrMsg: ['', [Validators.required]],
    });

    if (sessionStorage.getItem('userData')) {
      this.userData = JSON.parse(sessionStorage.getItem('userData'));

      // Check the user is authorized to upload a file
      // isObject(this.userData) && !isNull(this.userData.adminAccess)
      isObject(this.userData) && isNull(this.userData.adminAccess)
        ? (this.isAdminAccess = true)
        : (this.isAdminAccess = false);
    } else {
      this.userData = {};
    }
  }

  open(content) {
    this.files = [];
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title' })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;
        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onSelectFile($evt) {
    if ($evt !== undefined) {
      const fileName = $evt.target.files[0].name;
      const fileExt = fileName.split('.').pop();
      if (this.validFileTypes.indexOf(fileExt) > -1) {
        this.form.controls['uploadErrMsg'].setErrors(null);
      } else {
        this.form.controls['uploadErrMsg'].setErrors({ uploadErrMsg: true });
      }
      this.onFileChange($evt);
    }
    return false;
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.form.get('avatar').setValue(file);
    }
  }

  disableAlert(timer) {
    return setTimeout(() => {
      this.closeAlert = false;
    }, timer);
  }

  onSubmit() {
    for (const droppedFile of this.files) {
      // Is it a file?
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {
          // Here you can access the real file
          console.log(
            'relative Path',
            droppedFile.relativePath,
            droppedFile,
            file
          );

          // You could upload it like this:
          const formData = new FormData();
          formData.append('file', file, droppedFile.relativePath);

          this.uploadService.callUploadFileService(formData).subscribe(
            (res) => {
              this.uploadResponse = res;
              this.closeAlert = true;
              this.isUploadSuccess = true;
              this.successMessage = 'Changes saved successfully';
              this.disableAlert(2000);
            },
            (err) => {
              this.closeAlert = true;
              this.isUploadSuccess = false;
              this.successMessage = 'The upload file is empty';
              this.error = err;
              this.disableAlert(2000);
            }
          );
        });
      } else {
        // It was a directory (empty directories are added, otherwise only files)
        const fileEntry = droppedFile.fileEntry as FileSystemDirectoryEntry;
        console.log(droppedFile.relativePath, fileEntry);
      }
    }
  }

  closeDialog() {
    this.vc.clear();
    document.body.removeChild(this.backdrop);
  }
}
