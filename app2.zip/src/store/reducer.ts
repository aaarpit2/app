// importing Actions
import * as UserActions from './actions';

export interface State {
  loading: boolean;
  results: Object;
}

const initialState: State = {
  loading: false,
  results: {},
};

export function reducer(
  state = initialState,
  action: UserActions.Actions
): State {
  switch (action.type) {
    case UserActions.FETCH_USER_DETAILS: {
      return {
        ...state,
        loading: true,
      };
    }
    case UserActions.FETCH_USER_DETAILS_DONE: {
      return {
        ...state,
        loading: false,
        results: action.payload,
      };
    }
    default: {
      return state;
    }
  }
}
