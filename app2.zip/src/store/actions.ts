import { Injectable } from '@angular/core';
import { Action, Store } from '@ngrx/store';

// True while fetching data from API
export const LOADING = 'Food User';

// Fetching User Details
export const FETCH_USER_DETAILS = 'Fetch User Details';
export const FETCH_USER_DETAILS_DONE = 'Fetch User Details Done';

export class FetchUserDetails implements Action {
  readonly type = FETCH_USER_DETAILS;
}

export class FetchUserDetailsDone implements Action {
  readonly type = FETCH_USER_DETAILS_DONE;
  constructor(public payload: any) {}
}

export type Actions = FetchUserDetails | FetchUserDetailsDone;
