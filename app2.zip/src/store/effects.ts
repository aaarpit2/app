import { Injectable } from '@angular/core';
import { Effect, Actions } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
import { createEffect, ofType } from '@ngrx/effects';
import { EMPTY } from 'rxjs';
import { map, mergeMap, catchError } from 'rxjs/operators';

import * as UserActions from './actions';
import { UserProfileService } from 'src/userprofile/userprofile.service';

@Injectable()
export class UserEffects {
  constructor(
    private actions$: Actions,
    private userProfileService: UserProfileService
  ) {}

  @Effect()
  fetchUser$: Observable<Action> = this.actions$
    // Listen for the 'FETCH_USER_DETAILS' action
    .filter((action) => action.type === UserActions.FETCH_USER_DETAILS)
    // .map(toPayload)
    .switchMap(() => {
      return this.userProfileService
        .fetchUserDetail()
        .map((results) => new UserActions.FetchUserDetailsDone(results));
    });

  /*fetchUser1$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserActions.FETCH_USER_DETAILS),
      mergeMap(() =>
        this.userProfileService.fetchUserDetail().pipe(
          map((results) => new UserActions.FetchUserDetailsDone(results)),
          catchError(() => EMPTY)
        )
      )
    )
  );*/
}
