import { Component, Input } from '@angular/core';

@Component({
  selector: 'access',
  templateUrl: './access.component.html'
})
export class AccessComponent {
  @Input() userId: string;
  @Input() url: string;
  @Input() htmlresponse: string;

  constructor() {
	}

  ngOnInit(): void {
   
  }
}
